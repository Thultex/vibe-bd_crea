Ruckpacken nanDECK-Paket

Enthält cards.csv, cards_long.csv, symbols.csv, ruckpacken.ndeck und 73 nummerierte PNG-Platzhalter.
Die sechs Ergänzungen sind Brille, Zeitung, Kerze, Schüssel, Mikrofon und Regenschirm.
